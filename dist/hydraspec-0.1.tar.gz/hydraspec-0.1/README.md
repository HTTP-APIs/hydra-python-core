# hydra-python-core
This library provides the core functions to implement Hydra Official Specification in Python.


*Porting out from hydrus the hydraspecs directory*
